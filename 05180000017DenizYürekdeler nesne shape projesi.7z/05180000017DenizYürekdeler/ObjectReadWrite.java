import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class ObjectReadWrite {
	
	ShapeList<Shape> shapelist = new ShapeList<Shape>();
	
	public void readObj(){ 
		{ 
			
			try {
				File file = new File("C:\\Users\\dyure\\Desktop\\Object.txt");
	         
	            Scanner sc = new Scanner(file);

	           while(sc.hasNextLine()){
	        	   
	               String line = sc.nextLine();
	             
	               String[] details = line.split("\\s+"); //splitting by spaces
	               
	               String shapetypetitle = details[0]; //title
	               String shapecoor = details[1]; //whole coords
	               String argu1 = details[2]; //edge/radius for all shapes
	               
	               String shapecoordetails[] = shapecoor.split(","); //split coordinates again (x,y) --> [(x]    [y)]
	               
	               String coorx = shapecoordetails[0].substring(1, shapecoordetails[0].length()); //skip '(' and read rest
	               String coory = shapecoordetails[1].substring(0, shapecoordetails[1].length()-1); //start reading until ')'
	             
	                if(shapetypetitle.equals("Rectangle")) {
	                	
	            	   	String argu2 = details[3]; //edge2 is required for rectangle
	            	   	
	                	double edge = Double.valueOf(argu1);
	                    double edge2 = Double.valueOf(argu2);
	                    int x=Integer.valueOf(coorx);
	                	int y=Integer.valueOf(coory);
	                    Rectangle p = new Rectangle(edge,edge2,x,y);
	                    shapelist.add(p); 
	                   
	                }
	                else if(shapetypetitle.equals("Square")){
	                	
	                	double edge= Double.valueOf(argu1);
	                	int x=Integer.valueOf(coorx);
	                	int y=Integer.valueOf(coory);
	                	Square p = new Square(edge,x,y);
	                	shapelist.add(p);
	                	
	                }
	                else if(shapetypetitle.equals("Circle")) {
	                	double radius= Double.valueOf(argu1);
	                	int x=Integer.valueOf(coorx);
	                	int y=Integer.valueOf(coory);
	                	Circle p = new Circle(radius,x,y);
	                	shapelist.add(p);
	                	
	                }
	          }

	        } catch (FileNotFoundException e) {         
	            e.printStackTrace();
	        }
			
	   }
	}
	
	public void writeObj() {
		
		Iterator<Shape> ite = shapelist.getIterator();
		while(ite.hasNext()) {
			Shape shape = ite.next();
			System.out.println(shape.toString());
		}
	}
}
