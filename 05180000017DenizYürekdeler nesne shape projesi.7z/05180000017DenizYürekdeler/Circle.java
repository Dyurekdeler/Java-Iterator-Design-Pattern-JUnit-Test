
public class Circle implements Shape{
	
	double radius;
	int x,y;
	double pi=3.14;
	
	public Circle(double radius, int x, int y) {
		this.radius=radius;
		this.x=x;
		this.y=y;
	}
	
	public double calculateArea() {
		return pi*radius*radius;
	}
	public double calculatePerimeter() {
		return 2*pi*radius;
	}
	public String toString() {
		return "Circle    = " +" Radius = "+radius+" Coordinates = ("+ x +"," + y + ")  Area ="+calculateArea()+" Perimeter = " + calculatePerimeter();
	}
}
