
public class Rectangle implements Shape{
	
	double edgeshort,edgelong;
	int x,y;
	
	public Rectangle(double edgeshort, double edgelong, int x, int y) {
		this.edgeshort=edgeshort;
		this.edgelong=edgelong;
		this.x=x;
		this.y=y;
	}
	
	public double calculateArea() {
		return edgeshort*edgelong;
	}
	public double calculatePerimeter() {
		return (edgeshort+edgelong)*2;
	}
	public String toString() {
		return "Rectangle = " + " Width = "+edgeshort+ " Length = "+edgelong+" Coordinates = ("+ x +"," + y + ")  Area ="+calculateArea()+" Perimeter = " + calculatePerimeter();
	}
}
