
public interface Shape<E> {

	double calculateArea();
	double calculatePerimeter();
}
