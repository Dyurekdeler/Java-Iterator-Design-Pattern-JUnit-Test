import java.util.ArrayList;

public class ShapeList<E> implements Collection<E>{
	
	public ArrayList<E> shapes;
	
	
	public ShapeList() {
		shapes =  new ArrayList<E>() ;
	}
	
	public ArrayList<E> getlist(){
		
	    return shapes;
	}
	
	public void add(E obj) {
		shapes.add(obj);
	}
	public E get(int i) {
		return shapes.get(i);
	}
	public int size() {
		return shapes.size();
	}
	
	@Override
	public Iterator<E> getIterator() {
		return new ShapeIterator();
	}
	
	
	private class ShapeIterator<E> implements Iterator<E>{ //inner class
		
		int current=0;
		
		@Override
		public boolean hasNext() {
			if(current<shapes.size() && shapes.get(current)!=null) //not reached to end of the list and element is not null
				return true;
			
				else
					return false;
			}
		
		@Override
		public E next() {
			return (E) shapes.get(current++);
			
		}
	}
}
