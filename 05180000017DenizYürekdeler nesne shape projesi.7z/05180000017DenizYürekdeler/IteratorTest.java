import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class IteratorTest {
	
	Rectangle r = new Rectangle(1,2,3,4);
	Square s = new Square(4,5,6);
	Circle c = new Circle(1,4,7);
	
	ShapeList shapelist = new ShapeList();
	
	void additems() {
		
		shapelist.add(r);
		shapelist.add(s);
		shapelist.add(c);
	}
	void addritem() {
		
		shapelist.add(r);
	}
	
	@Test //checking 0 element exists
	void sizeEmpty() {
		assertTrue(shapelist.getlist().isEmpty());
	}
	@Test //expected false when hasnext used in empty collection
	void hasNextEmpty() {
		assertFalse(shapelist.getIterator().hasNext());
	}
	@Test//expected throw exception because there is nothing next() can return
	public void ThrowsIndexOutOfBoundsExceptionEmpty() {
	  boolean thrown = false;

	  try {
	    shapelist.getIterator().next();
	  } catch (IndexOutOfBoundsException e) {
	    thrown = true;
	  }
	  assertTrue(thrown);
	}
	//////////////////////////////////////////// one item
	@Test
	void size1o() {//checking if one element exists
		addritem();
		assertEquals(1,shapelist.size());
	}
	@Test
	void hasNext1o() {//checking hasnext returns true on one-element list
		addritem();
		assertTrue(shapelist.getIterator().hasNext());
	}
	
	
	@Test//expected rectangle object
	public void next1o() { //expect next to return null
		addritem();
		assertEquals(shapelist.getIterator().next() , r);
		
	}
	@Test
	void size3o() {// checks if there are 3 objects in the list
		additems();
		assertEquals(3,shapelist.size());
	}
	@Test
	void hasnext3o() {//true when obj exists
		additems();
		Iterator<Shape> ite = shapelist.getIterator();
		while(ite.hasNext()) {
		assertTrue(shapelist.getIterator().hasNext());
		}
	}
	@Test
	public void next3o() { //it writes in the expected order
		additems();
		int expected=0;
		
		for(Iterator<Shape> ite = shapelist.getIterator();ite.hasNext()==true;ite.hasNext()) {
			for(int i=0;i<3;i++) {
				if(i==0) {
					if(ite.next().equals(r)) {
						expected+=1;
				}
				}
				if(i==1) {
					if(ite.next().equals(s)) {
						expected+=1;
				}
				}
				if(i==2) {
					if(ite.next().equals(c)) {
						expected+=1;
				}
				}
					
			}
		
		}
		assertTrue(expected==3);
	}
}
