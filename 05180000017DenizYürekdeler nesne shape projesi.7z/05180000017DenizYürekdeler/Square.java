
public class Square implements Shape {
	
	double edge;
	int x,y;
	
	public Square(double edge, int x, int y) {
		this.edge=edge;
		this.x=x;
		this.y=y;
	}
	
	public double calculateArea() {
		return edge*edge;
	}
	public double calculatePerimeter() {
		return edge*4;
	}
	public String toString() {
		return "Square    = " +" Edge = "+edge+" Coordinates = ("+ x +"," + y +")  Area ="+calculateArea()+" Perimeter = " + calculatePerimeter();
	}

}
