
public interface Collection<E> {
	
	Iterator<E> getIterator();
}
